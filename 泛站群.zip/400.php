﻿<html>
<head>
<meta charset="utf-8">
<title>404 Not Found</title>
</head>
<body>
<div class="ts1">
<p style="font-size:5.0rem;">404 Not Found</p>
</div>
<div class="ts2">
<div class="ts2_t">
<p>The requested URL was not found on this server.</p>
<p>您要找的内容已被删除</p>
更多相关内容
<?php
include_once 'functions.php';
include_once 'dbclass.php';
header('Content-type: text/html; charset=utf-8');
$domian = $_SERVER['SERVER_NAME'];
$db = new db();
$qianzhui = array('m.','www.','');
for($i = 0 ; $i <10; $i++){
$home_url = $db->home_url();

echo '<li><a href="http://'.$qianzhui[rand(0,2)].parseHost($domian).'/'.$home_url.'" target="_blank">'.$home_url.'</a>
					</li>';
}
?>

</div>
</div>
</body>
</html>
